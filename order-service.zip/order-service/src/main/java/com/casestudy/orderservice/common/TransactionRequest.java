package com.casestudy.orderservice.common;

import com.casestudy.orderservice.entity.Order;

public class TransactionRequest {
	
	private Order order;
	private Payment paymant;
	
	public TransactionRequest()
	{
		
	}
	public TransactionRequest(Order order, Payment paymant) {
		super();
		this.order = order;
		this.paymant = paymant;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Payment getPaymant() {
		return paymant;
	}
	public void setPaymant(Payment paymant) {
		this.paymant = paymant;
	}
	
	
	

}
